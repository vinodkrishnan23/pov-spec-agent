"""Generated cross-language contracts consumed by agent-engine-runner-shared."""
