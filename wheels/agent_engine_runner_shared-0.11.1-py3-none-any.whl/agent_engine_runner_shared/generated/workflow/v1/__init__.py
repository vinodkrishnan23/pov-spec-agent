"""Version 1 durable-workflow contracts."""
