"""Backend implementations for Magenta deep agent integration.

``MagentaToolPodBackend`` (canonical name: ``MagentaToolSandboxBackend``)
is intentionally NOT imported eagerly from this package. It lives in
``.toolpod`` (or ``.tool_sandbox`` for the canonical name) which imports
from ``deepagents``, and ``deepagents`` is an optional dependency — any
code path that doesn't use deep agents must be able to ``import
magenta_sdklanggraph.backends`` without pulling ``deepagents`` in.

Import it explicitly when you need it:

    from magenta_sdklanggraph.backends.tool_sandbox import MagentaToolSandboxBackend

``MagentaToolPodBackend`` remains available as a deprecated alias::

    from magenta_sdklanggraph.backends.toolpod import MagentaToolPodBackend
"""

__all__: list[str] = []
