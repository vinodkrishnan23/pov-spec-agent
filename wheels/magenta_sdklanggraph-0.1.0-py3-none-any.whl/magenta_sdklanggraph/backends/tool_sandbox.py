"""MagentaToolSandboxBackend — canonical name for MagentaToolPodBackend.

This module exists so agent authors can use the stable sandbox terminology
without depending on the legacy AER/ToolPod names. The implementation is
identical; both names refer to the same class.

.. code-block:: python

    from magenta_sdklanggraph.backends.tool_sandbox import MagentaToolSandboxBackend
"""

from __future__ import annotations

from magenta_sdklanggraph.backends.toolpod import MagentaToolPodBackend

MagentaToolSandboxBackend = MagentaToolPodBackend
"""Canonical name for MagentaToolPodBackend.

``MagentaToolSandboxBackend is MagentaToolPodBackend`` — both names
resolve to the same class object. Use the canonical name in new code.
"""

__all__ = ["MagentaToolSandboxBackend"]
