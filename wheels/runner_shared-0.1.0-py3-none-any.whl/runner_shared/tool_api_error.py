"""Classify external API call failures into structured, safe metadata."""

from __future__ import annotations

import json
from typing import Any

import httpx
from pydantic import BaseModel, Field

from runner_shared.error_reporting import _redact_text

_MAX_ERROR_CODE_LEN = 128
_MAX_REASON_LEN = 256
_MAX_ENVELOPE_BODY = 4096

_STATUS_CLASSIFICATIONS: dict[int, tuple[str, bool]] = {
    401: ("AUTH_FAILED", False),
    403: ("AUTH_FAILED", False),
    429: ("RATE_LIMITED", True),
    503: ("PROVIDER_UNAVAILABLE", True),
}


class ToolAPIError(BaseModel):
    provider_type: str | None = Field(default=None, description="Provider identity when known")
    classification: str = Field(
        description=(
            "AUTH_FAILED, RATE_LIMITED, PROVIDER_UNAVAILABLE, TIMEOUT, CONNECTION_ERROR, or UNKNOWN"
        )
    )
    http_status: int | None = Field(
        default=None, description="HTTP status when the failure was an HTTP response"
    )
    retryable: bool = Field(
        default=False,
        description=(
            "Provider-condition guidance only. Must not trigger replay of an "
            "already-dispatched tool call."
        ),
    )
    error_code: str | None = Field(default=None, description="Bounded redacted provider error code")
    reason: str | None = Field(
        default=None, description="Bounded redacted provider reason; URLs dropped"
    )


def classify_tool_api_error(
    exc: BaseException,
    provider_type: str | None,
) -> tuple[ToolAPIError, str] | None:
    """Return structured metadata and a safe message, or None."""
    if isinstance(exc, httpx.TimeoutException):
        return _result(provider_type, "TIMEOUT", None, True), _msg(provider_type, "TIMEOUT")
    if isinstance(exc, httpx.ConnectError):
        return (
            _result(provider_type, "CONNECTION_ERROR", None, True),
            _msg(provider_type, "CONNECTION_ERROR"),
        )
    if isinstance(exc, httpx.HTTPStatusError):
        return _classify_http(exc.response.status_code, exc.response, provider_type)

    try:
        import requests
    except ImportError:
        return None

    if isinstance(exc, requests.exceptions.Timeout):
        return _result(provider_type, "TIMEOUT", None, True), _msg(provider_type, "TIMEOUT")
    if isinstance(exc, requests.exceptions.ConnectionError):
        return (
            _result(provider_type, "CONNECTION_ERROR", None, True),
            _msg(provider_type, "CONNECTION_ERROR"),
        )
    if isinstance(exc, requests.exceptions.HTTPError):
        response = getattr(exc, "response", None)
        status = getattr(response, "status_code", None)
        return _classify_http(status, response, provider_type)

    return None


def _result(
    provider_type: str | None,
    classification: str,
    http_status: int | None,
    retryable: bool,
    error_code: str | None = None,
    reason: str | None = None,
) -> ToolAPIError:
    return ToolAPIError(
        provider_type=provider_type,
        classification=classification,
        http_status=http_status,
        retryable=retryable,
        error_code=error_code,
        reason=reason,
    )


def _msg(provider_type: str | None, classification: str) -> str:
    return f"{provider_type or 'External'} API call failed: {classification}"


def _classify_http(
    status: int | None,
    response: Any,
    provider_type: str | None,
) -> tuple[ToolAPIError, str]:
    classification, retryable = _STATUS_CLASSIFICATIONS.get(status or 0, ("UNKNOWN", False))
    error_code, reason = _extract_envelope(response)
    error = _result(provider_type, classification, status, retryable, error_code, reason)
    detail = f"HTTP {status} {classification}" if status is not None else classification
    return error, _msg(provider_type, detail)


def _extract_envelope(response: Any) -> tuple[str | None, str | None]:
    if response is None:
        return None, None
    raw = getattr(response, "_content", None)
    if not isinstance(raw, (bytes, bytearray)):
        return None, None
    if len(raw) > _MAX_ENVELOPE_BODY:
        return None, None
    try:
        body = json.loads(bytes(raw))
    except Exception:
        return None, None
    if not isinstance(body, dict):
        return None, None
    error_code = None
    reason = None
    raw_code = body.get("errorCode")
    raw_reason = body.get("reason")
    if isinstance(raw_code, str):
        error_code = _safe_envelope_text(raw_code, _MAX_ERROR_CODE_LEN)
    if isinstance(raw_reason, str):
        reason = _safe_envelope_text(raw_reason, _MAX_REASON_LEN)
    return error_code, reason


def _safe_envelope_text(text: str, max_len: int) -> str | None:
    if "://" in text:
        return None
    redacted = _redact_text(text)[:max_len]
    return redacted or None
