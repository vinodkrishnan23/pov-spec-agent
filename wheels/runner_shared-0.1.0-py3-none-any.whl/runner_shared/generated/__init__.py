"""Generated cross-language contracts consumed by runner-shared."""
