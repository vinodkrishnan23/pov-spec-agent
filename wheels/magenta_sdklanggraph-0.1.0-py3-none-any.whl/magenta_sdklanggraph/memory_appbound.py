"""Backwards-compatible re-export of the shared app-bound memory adapters.

The implementation lives in :mod:`runner_shared.memory_appbound` so every
Python framework adapter (LangGraph, ADK, framework-light) shares one
behavior. Import from ``runner_shared`` in new code; this module remains only
so existing ``magenta_sdklanggraph.memory_appbound`` imports keep working.
"""

from runner_shared.memory_appbound import AppBoundCrudClient, AppBoundRuntime

__all__ = ["AppBoundCrudClient", "AppBoundRuntime"]
