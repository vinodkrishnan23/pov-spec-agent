"""LangChain SDK for MongoDB Agentic Platform.

``MagentaToolSandboxBackend`` (deprecated: ``MagentaToolPodBackend``) and
``create_magenta_deep_agent`` are intentionally NOT re-exported at the
package root. They depend on the optional ``deepagents`` extra and importing
them eagerly from ``__init__.py`` would break any downstream package that
depends on ``magenta-sdklanggraph`` without also declaring ``deepagents``.
Import them directly when needed::

    from magenta_sdklanggraph.deep_agent import create_magenta_deep_agent
    from magenta_sdklanggraph.backends.tool_sandbox import MagentaToolSandboxBackend

Or, for the common case, use ``App.deep_agent()`` which lazy-imports both.
"""

from .agent import LangGraphBaseAgent
from .durable_errors import UnsupportedDurableGraphError
from .output_parser import LangGraphOutputParser, RawStreamItem
from .platform_checkpointer import PlatformCheckpointer
from .runtime import App
from agentic_platform_memory import Memory
from runner_shared import SessionFinishStatus

# Memory is re-exported from agentic-platform-memory for a stable import path.
# ``magenta_sdklanggraph.Memory is agentic_platform_memory.Memory`` (same object).
# For app-bound ambient identity, use App.memory; constructing
# Memory(service_account_token=...) / Memory(base_url=...) is the HTTP/direct path.

__all__ = [
    "App",
    "LangGraphBaseAgent",
    "LangGraphOutputParser",
    "Memory",
    "PlatformCheckpointer",
    "RawStreamItem",
    "SessionFinishStatus",
    "UnsupportedDurableGraphError",
]
