"""Generated durable-workflow contracts."""
